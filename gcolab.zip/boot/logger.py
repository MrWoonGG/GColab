import datetime

# Класс логера
class Logger(object):
    """Простой логгер"""

    # Делаем инит и указываем файл и режим работы
    def __init__(self, mode, file=None):
        self.file = file
        self.mode = mode
        
        # Проверка указан ли файл
        if self.file is None and (self.mode == "file" or self.mode == "all"):
            raise AttributeError("Файл не указан. Невозможно выполнить запись лога.")

    # Функция для лога
    def log(self, Ltype, Ltext, mode=None):
        if mode is None:
            mode = self.mode

        if self.file is None and (mode == "file" or mode == "all"):
            raise AttributeError("Файл не указан. Невозможно выполнить запись лога.")
        
        if mode == "file" or mode == "all":
            with open(self.file, "a", encoding='utf-8') as logFile:
                logFile.write(f"{datetime.datetime.today().strftime('%d-%m-%Y %H:%M:%S')} [{Ltype.upper()}] {Ltext}\n")
        
        if mode == "console" or mode == "all":
            print(f"{datetime.datetime.today().strftime('%d-%m-%Y %H:%M:%S')} [{Ltype.upper()}] {Ltext}")

    # Функция для очистки лог-файла
    def clear(self):
        if self.file is not None:
            open(self.file, "w").close()

def main(err):
    raise AttributeError(err)

if __name__ == "__main__":
    err = "Это модуль, а не скрипт. Пожалуйста, импортируйте его"
    main(err)