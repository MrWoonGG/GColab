# Создаём класс для настроек
class config(object):
    """Работа с файлами настроек"""

    # Делаем инит создавая переменную файла
    def __init__(self, file):
        super(config, self).__init__()
        self.file = file
    
    # Функция для получения строки
    def get(self, name):
        with open(self.file, "r+") as cfg:
            for i in cfg.readlines():
                if i.split("=")[0] == name:
                    return str(i.split("=")[1].strip()[1 : -1].strip())
        return None
    
    # Функция для установки строки
    def set(self, name, text):
        with open(self.file, "r+") as cfg:
            lines = cfg.readlines()
            for i in range(len(lines)):
                if lines[i].split("=")[0] == name:
                    lines[i] = name + "=" + "\"" + text + "\"" + "\n"
                    cfg.seek(0)
                    cfg.writelines(lines)
                    return True
        return False
    
    # Функция для создания строки
    def new(self, name, text):
        try:
            with open(self.file, "a") as cfg:
                nNot = False
                with open(self.file, "r") as  cfg2:
                    lines = cfg2.readlines()
                    try:
                        if lines[len(lines) - 1] != "\n":
                            nNot = True
                    except IndexError as e:
                        nNot = None
                if nNot == True:
                    cfg.write("\n" + name + "=" + "\""+text+"\"".strip())
                if nNot == False:
                    cfg.write(name + "=" + "\""+text+"\"".strip() + "\n")
                if nNot == None:
                    cfg.write(name + "=" + "\""+text+"\"".strip())
                return True
        except Exception as e:
            return False

    # Функция для очистки всего файла настроек
    def clear(self):
        with open(self.file, "w") as cfg:
            cfg.write("")
        return True

def main():
    raise AttributeError("Это модуль, а не скрипт. Пожалуйста, импортируйте его")

if __name__ == "__main__":
    main()