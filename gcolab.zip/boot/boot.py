# Импорт модулей
import threads
import os
from config import config
import subprocess
import time
from datetime import datetime
from logger import Logger

# Создание переменой для логера
logger = Logger("all", "logs/" + datetime.now().strftime('%Y-%m-%d_%H-%M-%S') + ".txt")

# Запуск основы среды
logger.log('info', "[WoonEnv] Загрузка...")
logger.log('warn', "[WoonEnv] Данная 'среда' находится в бета-тесте, поэтому возможны ошибки.")

# Создание переменой для настроек
cfg = config("config.txt")

# Проверка настроек
logger.log("info", "[WoonEnv] Проверка настроек...")
def ifCfg(cfgstr, value):
	if cfg.get(cfgstr) == None:
		cfg.new(cfgstr, value)

ifCfg("scripts", "main.py")
ifCfg("engines", "python:py")
ifCfg("requirements-file", "requirements.txt")
ifCfg("env-type", "default")
# ...

# Чтение настроек
logger.log("info", "[WoonEnv] Загрузка настроек...")
engines = cfg.get("engines").split(";")
enginecmds = []
enginefiles = []

for engine in engines:
	enginecmds.append(engine.split(":")[0])
	enginefiles.append(engine.split(":")[1])

scripts = cfg.get("scripts").split(";")
start_scripts = []
for script in scripts:
	for i in range(len(enginefiles)):
		if script.endswith(enginefiles[i]):
			if "python" in enginecmds[i]:
				start_scripts.append([enginecmds[i], '-u', script])
			else:
				start_scripts.append([enginecmds[i], script, script])

# Установка зависимостей с файла
logger.log("info", "[WoonEnv] Установка зависимостей...")
with subprocess.Popen(["python", "-u", "-m", "pip", "install", "-r", "../" + cfg.get("requirements-file")], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True) as process:
	for line in process.stdout:
		logger.log("info", (f'[WoonEnv: pip] {line.strip()}'))

# Функция для запуска скрипта в потоке
logger.log("info", "[WoonEnv] Запуск скриптов в фоновом режиме...")
@threads.thread
def startCommand(cmdreal, cmd, kd):
	startStop = False
	try:
		open("../" + cmdreal[2], "r").close()
	except:
		logger.log("error", f'[WoonEnv: {cmdreal[2]}] Не удаётся найти файл. Пожалуйста, проверьте расположение файла.')
		startStop = True

	time.sleep(kd)
	timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
	folder = "logs/" + cmdreal[2]
	os.makedirs(folder, exist_ok=True)
	filenamec = folder + "/" + timestamp + ".txt"

	with open(filenamec, "w", encoding='utf-8') as file:
		file.write("")

	if not startStop:
		with subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True) as process:
			for line in process.stdout:
				logger.log("info", (f'[WoonEnv: {cmdreal[2]}] {line.strip()}'))
				with open(filenamec, "a", encoding='utf-8') as file:
					file.write(line)


# Проходимся по скриптам из настроек и запускаем их
kd = 0.0
for cmd in start_scripts:
	cmd1 = cmd[0]
	cmd2 = cmd[1]
	cmd3 = "../" + cmd[2]
	logger.log('info', f'[WoonEnv] Запуск скрипта {cmd[2]} при помощи {cmd[0].capitalize()}...')
	startCommand(cmd, [cmd1, cmd2, cmd3], kd)
	kd = kd + 0.001

# Делаем маленькую задержку и пишем об успешном запуске
time.sleep(0.0001)
logger.log('info', f'[WoonEnv] Скрипты успешно запущены!')