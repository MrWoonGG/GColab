import threading

# Функция для принудительной остановки потока
def stopThread(thread):
    if thread.is_alive():
        thread._stop()

# Функция декоратора для запуска функции в потоке
def thread(func):
	def wrapper(*args, **kwargs):
		threading.Thread(target=func, args=args).start()
	return wrapper